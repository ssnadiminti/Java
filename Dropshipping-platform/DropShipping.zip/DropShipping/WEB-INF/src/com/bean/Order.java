package com.bean;

public class Order {
	private Long orderId;
	private Long userId;
	private String createdDate;
	private String checkoutflag;
	private String orderUniqueId;
	private String paymentMethod;
	private Long couponId;
	private String orderEmail;
	public String getOrderEmail() {
		return orderEmail;
	}
	public void setOrderEmail(String orderEmail) {
		this.orderEmail = orderEmail;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCheckoutflag() {
		return checkoutflag;
	}
	public void setCheckoutflag(String checkoutflag) {
		this.checkoutflag = checkoutflag;
	}
	public String getOrderUniqueId() {
		return orderUniqueId;
	}
	public void setOrderUniqueId(String orderUniqueId) {
		this.orderUniqueId = orderUniqueId;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public Long getCouponId() {
		return couponId;
	}
	public void setCouponId(Long couponId) {
		this.couponId = couponId;
	}	
}
