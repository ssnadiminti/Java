package com.dropshipping.cart;

import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.Order;
import com.bean.OrderItems;
import com.bean.OrderShipping;
import com.bean.Product;
import com.dropshipping.constants.DropShippingConstants;
import com.dropshipping.helper.DropShippingHelper;

public class CartAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		CartForm theForm = (CartForm) form;
		DropShippingHelper dropShippingHelper=new DropShippingHelper();
		HttpSession session=request.getSession();
		if("guest".equalsIgnoreCase(theForm.getAction())){
			return mapping.findForward("guest");
		}
		if("add".equalsIgnoreCase(theForm.getAction())){
			try{				
				String result="";
				String shortDesc=null;
				Long createdBy=null;
				String orderNumber=(String)session.getAttribute("orderNumber");
				Long userId=(Long)session.getAttribute("userId");
				if(orderNumber==null || orderNumber=="null" || (orderNumber!=null && orderNumber.trim().length()==0)){
					BigDecimal totalOrderPrice = new BigDecimal("0.00");
					if(request.getParameter("quantity")!=null && request.getParameter("quantity").length()!=0 
							&& request.getParameter("itemId")!=null && request.getParameter("itemId").length()!=0){
						String productId=request.getParameter("itemId");
						int quantity=Integer.parseInt(request.getParameter("quantity"));
						Product product=dropShippingHelper.getProductDetail(productId);
		        		if(product!=null && product.getPkgQty()<quantity){
							result="Product are not availabel to this quantity<p>0";
						}else{
							System.out.println("userId :"+userId);							
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
							String createdDate = sdf.format(new Date());
							orderNumber=dropShippingHelper.orderNumber();
							dropShippingHelper.insertOrder(userId,createdDate,"N",orderNumber,"CREDIT CARD");
							session.setAttribute("orderNumber",orderNumber);
							Long orderId =dropShippingHelper.getOrderId(orderNumber);
			        		
			        		if(orderId!=null && product!=null){
				        		dropShippingHelper.insertOrderItem(orderId,product.getPrice(),quantity,product.getSupplierPartNumber(),product.getManufacturerPartNumber(),product.getManufacturerName(),product.getDescription(),product.getUom(),product.getPkgQty(),product.getImageUrl());
				        		session.setAttribute("cartCount","1");
				        		result="success<p>1";
					        }
						}						
					}
				}else if(orderNumber!=null){
					Long orderId =dropShippingHelper.getOrderId(orderNumber);
					String productId=request.getParameter("itemId");
					int quantity=Integer.parseInt(request.getParameter("quantity"));
					Product product=dropShippingHelper.getProductDetail(productId);
					if(product!=null && product.getPkgQty()<quantity){
						result="Product are not availabel to this quantity<p>0";
					}else{
						OrderItems orderItems=dropShippingHelper.checkEcomOrderItem(orderId,product.getSupplierPartNumber(),product.getManufacturerPartNumber());
						if(orderItems!=null ){
							dropShippingHelper.updateCartProduct(orderItems.getOrderItemId(),(Integer.parseInt(orderItems.getOrderQty())+quantity));
							result="success<p>"+(String)session.getAttribute("cartCount");
						}else{
							if(product!=null){							
								dropShippingHelper.insertOrderItem(orderId,product.getPrice(),quantity,product.getSupplierPartNumber(),product.getManufacturerPartNumber(),product.getManufacturerName(),product.getDescription(),product.getUom(),product.getPkgQty(),product.getImageUrl());
								result="success<p>"+(Integer.parseInt((String)session.getAttribute("cartCount"))+1);
								session.setAttribute("cartCount",""+(Integer.parseInt((String)session.getAttribute("cartCount"))+1));
							}
						}
					}					
				}
				response.getWriter().write(result);
				System.out.println(result);
					
				return null;
			}catch (Exception e){
				e.printStackTrace();
			}
			return null;
		}
		if("update".equalsIgnoreCase(theForm.getAction())){
			try{
				String productId=request.getParameter("deleteProductId");
				String updateQty=request.getParameter("updateQty");
				if(productId!=null && productId.trim().length()!=0 && updateQty!=null && updateQty.trim().length()!=0){
					dropShippingHelper.updateCartProduct(Long.parseLong(productId),(Integer.parseInt(updateQty.trim())));
				}
				theForm.setAction("view");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("delete".equalsIgnoreCase(theForm.getAction())){
			try{
				String deleteProductId=request.getParameter("deleteProductId");
				if(deleteProductId!=null && deleteProductId.trim().length()!=0){
					dropShippingHelper.deleteOrderItem(deleteProductId);
				}
				theForm.setAction("view");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		
		if("view".equalsIgnoreCase(theForm.getAction())){
			try{
				String orderNumber=(String)session.getAttribute("orderNumber");
				if(orderNumber!=null && orderNumber.trim().length()!=0){
					ArrayList cartOrderItemsList=dropShippingHelper.cartOrderItem(orderNumber);
					if(cartOrderItemsList!=null && cartOrderItemsList.size()!=0){
						session.setAttribute("cartOrderItemsList",cartOrderItemsList);
						session.setAttribute("cartCount",cartOrderItemsList.size());
					}else{
						session.setAttribute("cartOrderItemsList",null);
						session.setAttribute("cartCount","0");
					}
					String totalPrice=dropShippingHelper.totalCartPrice(orderNumber);
					if(totalPrice!=null && totalPrice.trim().length()!=0){
						session.setAttribute("totalPrice",totalPrice);
					}else{
						session.setAttribute("totalPrice",null);
					}
				}else{
					session.setAttribute("cartOrderItemsList",null);
					session.setAttribute("totalPrice",null);
					session.setAttribute("cartCount","0");
				}
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		
		if("shipping".equalsIgnoreCase(theForm.getAction())){
			try{
				String guestUserName=request.getParameter("guestUserName");
				if(guestUserName!=null && guestUserName.trim().length()!=0){
					session.setAttribute("guestUserName", guestUserName);
				}
				OrderShipping orderShipping=(OrderShipping)session.getAttribute("orderShippingInfo");
				if(orderShipping!=null){
					theForm.setAddressLine1(orderShipping.getAddressLine1());
					theForm.setAddressLine2(orderShipping.getAddressLine2());
					theForm.setCity(orderShipping.getCity());
					theForm.setState(orderShipping.getState());
					theForm.setCountry(orderShipping.getCountry());
					theForm.setZipCode(orderShipping.getZipCode());
				}
				return mapping.findForward("shipping");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("shippingMethod".equalsIgnoreCase(theForm.getAction())){
			try{
				OrderShipping orderShipping=new OrderShipping();
				orderShipping.setAddressLine1(theForm.getAddressLine1());
				orderShipping.setAddressLine2(theForm.getAddressLine2());
				orderShipping.setCity(theForm.getCity());
				orderShipping.setState(theForm.getState());
				orderShipping.setCountry(theForm.getCountry());
				orderShipping.setZipCode(theForm.getZipCode());
				session.setAttribute("orderShippingInfo",orderShipping);
				return mapping.findForward("shippingMethod");
			}catch (Exception e){
				e.printStackTrace();
			}
		}		
		if("paymentMethod".equalsIgnoreCase(theForm.getAction())){
			try{
				String shipMethodInfo=request.getParameter("shipMethodInfo");
				if(shipMethodInfo!=null && shipMethodInfo.trim().length()!=0){
					OrderShipping orderShipping=(OrderShipping)session.getAttribute("orderShippingInfo");
					if(orderShipping!=null){
						orderShipping.setShippingMethod(shipMethodInfo.split(" ")[0]);
						orderShipping.setShippingPrice(""+String.format("%.2f",Double.parseDouble(shipMethodInfo.split(" ")[1])));
						session.setAttribute("orderShippingInfo",orderShipping);
					}
					System.out.println(shipMethodInfo);
				}
				return mapping.findForward("paymentMethod");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("reviewOrder".equalsIgnoreCase(theForm.getAction())){
			try{
				String paymentMethodInfo=request.getParameter("paymentMethodInfo");
				if(paymentMethodInfo!=null && paymentMethodInfo.trim().length()!=0){
					session.setAttribute("paymentMethodInfo",paymentMethodInfo);					
				}
				String totalPrice=(String)session.getAttribute("totalPrice");
				OrderShipping orderShipping=(OrderShipping)session.getAttribute("orderShippingInfo");
				if(totalPrice!=null && totalPrice.trim().length()!=0 && orderShipping!=null){
					session.setAttribute("grandTotal",String.format("%.2f",(Double.parseDouble(totalPrice)+Double.parseDouble(orderShipping.getShippingPrice()))));
				}
				return mapping.findForward("reviewOrder");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("confirmOrder".equalsIgnoreCase(theForm.getAction())){
			try{
				OrderShipping orderShipping=(OrderShipping)session.getAttribute("orderShippingInfo");
				String orderNumber=(String)session.getAttribute("orderNumber");
				Long orderId=dropShippingHelper.getOrderId(orderNumber);;
				ArrayList cartOrderItemsList=dropShippingHelper.cartOrderItemsFromOrderId(""+orderId);
				for(int i=0;i<cartOrderItemsList.size();i++){
					OrderItems orderItems=(OrderItems)cartOrderItemsList.get(i);
					boolean check=dropShippingHelper.checkOrderQty(orderItems.getSupplierPartNumber(),orderItems.getManufacturerPartNumber(),Integer.parseInt(orderItems.getOrderQty()));
					if(check==true){
						String paymentMethodInfo=request.getParameter("paymentMethodInfo");
						if(paymentMethodInfo!=null && paymentMethodInfo.trim().length()!=0){
							session.setAttribute("paymentMethodInfo",paymentMethodInfo);					
						}
						String totalPrice=(String)session.getAttribute("totalPrice");
						orderShipping=(OrderShipping)session.getAttribute("orderShippingInfo");
						if(totalPrice!=null && totalPrice.trim().length()!=0 && orderShipping!=null){
							session.setAttribute("grandTotal",String.format("%.2f",(Double.parseDouble(totalPrice)+Double.parseDouble(orderShipping.getShippingPrice()))));
						}
						request.setAttribute("OrderPartNumber",orderItems.getSupplierPartNumber());
						request.setAttribute("OrderQtyError","OrderQtyError");
						return mapping.findForward("reviewOrder");
					}
				}
				if(orderShipping!=null && orderNumber!=null && orderNumber.trim().length()!=0){
					//orderId =dropShippingHelper.getOrderId(orderNumber);
					dropShippingHelper.insertOrderShipping(orderId, orderShipping);
					dropShippingHelper.updateOrder(orderId, (String)session.getAttribute("paymentMethodInfo"),(String)session.getAttribute("guestUserName"),(Long)session.getAttribute("userId"));
				}
				Order order=dropShippingHelper.getOrderFromOrderId(""+orderId);				
				if(order!=null && cartOrderItemsList!=null && cartOrderItemsList.size()!=0 && orderShipping!=null){
					StringBuffer xml=new StringBuffer();
					xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
					xml.append("<Order>\n");
					xml.append("<AccountNumber>"+DropShippingConstants.account+"</AccountNumber>\n");
					xml.append("<OrderNumber>"+(10000+orderId)+"</OrderNumber>\n");
					xml.append("<OrderCreatedDate>"+order.getCreatedDate()+"</OrderCreatedDate>\n");
					xml.append("<OrderPaymentMethod>"+order.getPaymentMethod()+"</OrderPaymentMethod>\n");
					xml.append("<OrderCreatedUser>"+order.getOrderEmail()+"</OrderCreatedUser>\n");
					xml.append("<OrderAddressLine1>"+orderShipping.getAddressLine1()+"</OrderAddressLine1>\n");
					xml.append("<OrderAddressLine2>"+orderShipping.getAddressLine2()+"</OrderAddressLine2>\n");
					xml.append("<OrderCity>"+orderShipping.getCity()+"</OrderCity>\n");
					xml.append("<OrderState>"+orderShipping.getState()+"</OrderState>\n");
					xml.append("<OrderCountry>"+orderShipping.getCountry()+"</OrderCountry>\n");
					xml.append("<OrderZipCode>"+orderShipping.getZipCode()+"</OrderZipCode>\n");
					for(int i=0;i<cartOrderItemsList.size();i++){
						OrderItems orderItems=(OrderItems)cartOrderItemsList.get(i);
						xml.append("<OrderItemNumber>"+orderItems.getOrderItemId()+"</OrderItemNumber>\n");
						xml.append("<OrderItemSupplierPartNumber>"+orderItems.getSupplierPartNumber()+"</OrderItemSupplierPartNumber>\n");
						xml.append("<OrderItemManufacturerName>"+orderItems.getManufacturername()+"</OrderItemManufacturerName>\n");
						xml.append("<OrderItemDescription>"+orderItems.getDescription()+"</OrderItemDescription>\n");
						xml.append("<OrderItemPrice>"+orderItems.getPrice()+"</OrderItemPrice>\n");
						xml.append("<OrderItemOrderQty>"+orderItems.getOrderQty()+"</OrderItemOrderQty>\n");
					}
					xml.append("</Order>");
					String fileName="";
					String shortFileName = "DropShipping_Order_"+(10000+orderId)+".xml";
					String filePath = DropShippingConstants.xmlPath;		
					try {
						( new File(filePath)).mkdirs();
						fileName = filePath + shortFileName;
						FileWriter file =  new FileWriter(fileName);
						file.write(xml.toString());
						file.close();
						System.out.println("File generates Successfully !!! ");
					}catch(Exception e){
						e.printStackTrace();
					}
				}				
				request.setAttribute("uniqueOrderId", (10000+orderId));
				session.setAttribute("cartCount","0");
				session.setAttribute("orderNumber",null);
				return mapping.findForward("confirmOrder");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("home".equalsIgnoreCase(theForm.getAction())){
			try{		
				session.setAttribute("guestUserName", null);
				session.setAttribute("cartOrderItemsList",null);
				session.setAttribute("totalPrice",null);
				session.setAttribute("grandTotal",null);
				session.setAttribute("paymentMethodInfo",null);
				session.setAttribute("orderShippingInfo",null);
				return mapping.findForward("home");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		return mapping.findForward("success");
	}
}
