package com.dropshipping.cart;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.Order;
import com.bean.OrderShipping;
import com.dropshipping.helper.DropShippingHelper;

public class OrdersViewAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		OrdersViewForm theForm = (OrdersViewForm) form;
		DropShippingHelper dropShippingHelper=new DropShippingHelper();
		HttpSession session=request.getSession();
		if("ordersView".equalsIgnoreCase(theForm.getAction())){
			String userRole=(String)session.getAttribute("userRole");
			Long userId=(Long)session.getAttribute("userId");
			ArrayList orderList=null;
			if(userRole!=null && userRole.trim().length()!=0 && userRole.equalsIgnoreCase("ADMIN")){
				orderList=dropShippingHelper.getAllOrders(null);
			}else if(userId!=null){
				orderList=dropShippingHelper.getAllOrders(userId);
			}
			request.setAttribute("orderList",orderList);
		}
		if("ordersAsnAck".equalsIgnoreCase(theForm.getAction())){
			String userRole=(String)session.getAttribute("userRole");
			Long userId=(Long)session.getAttribute("userId");
			ArrayList orderList=null;
			if(userRole!=null && userRole.trim().length()!=0 && userRole.equalsIgnoreCase("ADMIN")){
				orderList=dropShippingHelper.getAllOrders(null);
			}else if(userId!=null){
				orderList=dropShippingHelper.getAllOrders(userId);
			}
			request.setAttribute("orderList",orderList);
			return mapping.findForward("ordersAsnAck");
		}
		if("viewOrderDetails".equalsIgnoreCase(theForm.getAction())){
			String orderIdValue=request.getParameter("orderIdValue");
			if(orderIdValue!=null && orderIdValue.trim().length()!=0){
				Long orderId=(Long.parseLong(orderIdValue)-10000);
				if(orderId!=null){
					ArrayList cartOrderItemsList=dropShippingHelper.cartOrderItemsFromOrderId(""+orderId);
					if(cartOrderItemsList!=null && cartOrderItemsList.size()!=0){
						request.setAttribute("cartOrderItemsList",cartOrderItemsList);
					}
					String totalPrice=dropShippingHelper.totalCartPriceFromOrderId(""+orderId);
					request.setAttribute("totalPrice",totalPrice);
					session.setAttribute("totalPrice",totalPrice);session.setAttribute("totalPrice",totalPrice);
					Order order=dropShippingHelper.getOrderFromOrderId(""+orderId);
					request.setAttribute("orderInfo",order);
					OrderShipping orderShippingInfo=dropShippingHelper.getOrderShippingFromOrderId(""+orderId);
					request.setAttribute("orderShippingInfo",orderShippingInfo);
					request.setAttribute("orderNumber",orderIdValue);
				}
			}
			return mapping.findForward("viewOrderDetails");
		}
		if("viewOrderAsnAckDetails".equalsIgnoreCase(theForm.getAction())){
			String orderIdValue=request.getParameter("orderIdValue");
			if(orderIdValue!=null && orderIdValue.trim().length()!=0){
				Long orderId=(Long.parseLong(orderIdValue)-10000);
				if(orderId!=null){
					ArrayList cartOrderItemsList=dropShippingHelper.cartOrderItemsFromOrderId(""+orderId);
					if(cartOrderItemsList!=null && cartOrderItemsList.size()!=0){
						request.setAttribute("cartOrderItemsList",cartOrderItemsList);
					}
					Order order=dropShippingHelper.getOrderFromOrderId(""+orderId);
					request.setAttribute("orderInfo",order);
					OrderShipping orderShippingInfo=dropShippingHelper.getOrderShippingFromOrderId(""+orderId);
					request.setAttribute("orderShippingInfo",orderShippingInfo);
					request.setAttribute("orderNumber",orderIdValue);
				}
			}
			return mapping.findForward("viewOrderAsnAckDetails");
		}
		if("returns".equalsIgnoreCase(theForm.getAction())){
			request.setAttribute("returns","returns");
			return mapping.findForward("returns");
		}
		if("viewItems".equalsIgnoreCase(theForm.getAction())){			
			String orderIdValue=request.getParameter("orderIdValue");
			if(orderIdValue!=null && orderIdValue.trim().length()!=0){
				Long orderId=(Long.parseLong(orderIdValue)-10000);
				if(orderId!=null){
					ArrayList cartOrderItemsList=dropShippingHelper.cartOrderItemsFromOrderId(""+orderId);
					if(cartOrderItemsList!=null && cartOrderItemsList.size()!=0){
						request.setAttribute("cartOrderItemsList",cartOrderItemsList);
					}
				}
			}			
			return mapping.findForward("returns");
		}
		return mapping.findForward("success");
	}

}
