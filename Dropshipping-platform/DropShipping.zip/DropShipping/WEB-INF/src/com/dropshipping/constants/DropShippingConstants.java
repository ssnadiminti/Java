package com.dropshipping.constants;

import com.dropshipping.properties.DropShippingProperties;

public class DropShippingConstants {
	public static final String path = DropShippingProperties.get("basePath");
	public static final String xmlPath = DropShippingProperties.get("xmlPath");
	public static final String account = DropShippingProperties.get("account");
}
