package com.dropshipping.helper;

public class Tools {
	public static String uncross(String text, String key) {
		StringBuffer dec = new StringBuffer();

		String encChar = "";
		int count = 0, pos = 0;
		for (int loop = 0; loop < text.length(); loop++) {
			if (loop % 3 == 0) {
				encChar = text.substring(loop, loop + 3);

				if (loop > 0)
					pos = count % key.length();

				int intVal = (int) key.charAt(pos) ^ Integer.parseInt(encChar);

				dec.append((char) intVal);
				count++;
			}
		}
		return (dec.toString());
	}
	
	public static String cross(String text, String key) {
		StringBuffer enc = new StringBuffer();
		int c = 0;
		String encChar = "";
		for (int loop = 0; loop < text.length(); loop++) {
			c = (int) text.charAt(loop);
			encChar = (c ^ (int) key.charAt(loop % key.length())) + "";

			while (encChar.length() < 3)
				encChar = "0" + encChar;

			enc.append(encChar);
		}
		return (enc.toString());
	}
}
