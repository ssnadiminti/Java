package com.dropshipping.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.User;
import com.dropshipping.helper.DropShippingHelper;
import com.dropshipping.helper.Tools;

public class ForgotPasswordAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ForgotPasswordActionForm theForm = (ForgotPasswordActionForm) form;
		DropShippingHelper roboHelper=new DropShippingHelper();
		if("forgotPassword".equalsIgnoreCase(theForm.getAction())){
			try{
				return mapping.findForward("forgot");
			}catch (Exception e) {
				e.printStackTrace();
			}
			return mapping.findForward("forgot");
		}

		if("getPassword".equals(theForm.getAction())){
			if(theForm.getEmail() != null && theForm.getEmail().trim().length() != 0){
				User user=roboHelper.getUserDataFromEmail(theForm.getEmail().trim());
				if(user!=null){					
					String password=Tools.uncross(user.getPassword(), "23453452345");					
					StringBuffer mailBody = new StringBuffer("<html><body>" +
							"<p>Dear "+theForm.getEmail()+"<p>"+
							"<p>Your Password "+password+"<p>"+
							"<p>Please use this password to login into Robotic Shopping<p>"+
							"<p>Thank you.<p>"+
							"</body></html>");
					System.out.println(mailBody);					
					request.setAttribute("forgotPassword",password);
					request.setAttribute("errorMessage","success");
				}else{
					request.setAttribute("errorMessage","Email Address doesn't exists");
				}
			}
		}
		return mapping.findForward("forgot");
	}
}
