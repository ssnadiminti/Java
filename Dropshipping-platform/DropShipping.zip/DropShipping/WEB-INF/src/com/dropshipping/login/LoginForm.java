package com.dropshipping.login;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;


public class LoginForm extends ActionForm{
	private static final long serialVersionUID = 1L;	
	private String action;
	private String email;
	private String password;
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}	
	
	public ActionErrors validate( 
		ActionMapping mapping, HttpServletRequest request ) {
		ActionErrors errors = new ActionErrors();
		if( getEmail() == null || getEmail().length() < 1 ) {
			errors.add("name",new ActionMessage("error.userid.required"));
		}
		if( getPassword() == null || getPassword().length() < 1 ) {
			errors.add("address",new ActionMessage("error.password.required"));
		}
		return errors;	
	}
}
