package com.dropshipping.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dropshipping.helper.DropShippingHelper;
import com.dropshipping.helper.Tools;

public class RegistrationAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		RegistrationForm theForm = (RegistrationForm) form;		
		ActionErrors actionError = new ActionErrors();
		String action = request.getParameter("action");		
		HttpSession session=request.getSession();
		DropShippingHelper helper=new DropShippingHelper();
		try{
			if(action!=null && action.trim().length()!=0 && action.equalsIgnoreCase("saveUser")){
				System.out.println(theForm.getFirstName()+"     "+theForm.getLastName());
				helper.insertUser(theForm.getFirstName(), theForm.getLastName(), theForm.getUserEmail(), Tools.cross(theForm.getUserPassword(),"23453452345"), theForm.getMobile(), theForm.getSSN(), "CUSTOMER");
				request.setAttribute("savedUser", "savedUser");
			}
			if(action!=null && action.trim().length()!=0 && action.equalsIgnoreCase("checkUser")){
				String email=request.getParameter("email");
				if(email!=null && email.trim().length()!=0){
					String userEmail=helper.getUsersEmail(email);
					System.out.println(userEmail+" checking email is already exist or not");
					String result = "";
					if(userEmail==null){
						result += "success";
					}else{
						result += "failure";
					}
					response.getWriter().write(result);
					return null;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return mapping.findForward("success");
	}
}
