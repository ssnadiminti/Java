package com.dropshipping.products;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.Category;
import com.dropshipping.helper.DropShippingHelper;

public class CategoryAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		CategoryForm theForm = (CategoryForm) form;
		
		DropShippingHelper dropShippingHelper=new DropShippingHelper();
		if("add".equalsIgnoreCase(theForm.getAction())){
			try{
				theForm.setCategoryname("");
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("save".equalsIgnoreCase(theForm.getAction())){
			try{
				dropShippingHelper.insertCategory(theForm.getCategoryname());
				theForm.setAction("manageCategory");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("edit".equalsIgnoreCase(theForm.getAction())){
			try{
				String categoryIdValue=request.getParameter("categoryIdValue");
				if(categoryIdValue!=null && categoryIdValue.trim().length()!=0){
					Category category=dropShippingHelper.getCategoryDetail(categoryIdValue);
					if(category!=null){
						theForm.setCategoryname(category.getCategoryName());
						request.setAttribute("categoryIdValue", category.getCategoryId());
						request.setAttribute("editCategory", "editCategory");
					}
				}
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("update".equalsIgnoreCase(theForm.getAction())){
			try{
				String categoryIdValue=request.getParameter("categoryIdValue");
				if(categoryIdValue!=null && categoryIdValue.trim().length()!=0){
					dropShippingHelper.updateCategory(Long.parseLong(categoryIdValue),theForm.getCategoryname());
				}
				theForm.setAction("manageCategory");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("delete".equalsIgnoreCase(theForm.getAction())){
			try{
				String categoryIdValue=request.getParameter("categoryIdValue");
				System.out.println(categoryIdValue);
				if(categoryIdValue!=null && categoryIdValue.trim().length()!=0){
					dropShippingHelper.deleteCategory(categoryIdValue);
				}
				theForm.setAction("manageCategory");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		
		if("manageCategory".equalsIgnoreCase(theForm.getAction())){
			try{
				ArrayList categoryList=dropShippingHelper.getAllCategory();
				if(categoryList!=null && categoryList.size()!=0){
					request.setAttribute("categoryList",categoryList);
				}
				return mapping.findForward("manageCategory");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		return mapping.findForward("success");
	}
}
