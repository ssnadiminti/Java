package com.dropshipping.products;

import org.apache.struts.action.ActionForm;

public class CategoryForm extends ActionForm{
	private String action;
	private String categoryname;
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCategoryname() {
		return categoryname;
	}
	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}	
}
