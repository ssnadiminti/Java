package com.dropshipping.products;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.Product;
import com.dropshipping.helper.DropShippingHelper;

public class ProductAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ProductForm theForm = (ProductForm) form;
		DropShippingHelper dropShippingHelper=new DropShippingHelper();
		if("add".equalsIgnoreCase(theForm.getAction())){
			try{
				theForm.setSupplierPartNum("");
				theForm.setManufacturerPartNum("");
				theForm.setManufacturerName("");
				theForm.setDescription("");
				theForm.setPrice("");
				theForm.setUnitofmeasure("");
				theForm.setPkgqty("");
				theForm.setImageurl("");
				theForm.setUpc("");
				ArrayList categoryList=dropShippingHelper.getAllCategory();
				if(categoryList!=null && categoryList.size()!=0){
					request.setAttribute("categoryList",categoryList);
				}
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("save".equalsIgnoreCase(theForm.getAction())){
			try{
				System.out.println(theForm.getSupplierPartNum()+" "+theForm.getManufacturerName());
				dropShippingHelper.insertProduct(theForm.getSupplierPartNum(), theForm.getManufacturerPartNum(), theForm.getManufacturerName(), theForm.getDescription(), theForm.getUnitofmeasure(), theForm.getPkgqty(), theForm.getImageurl(), theForm.getPrice(), theForm.getUpc(),theForm.getCategoryId());
				theForm.setAction("manageProducts");
			}catch (Exception e){
				e.printStackTrace();
			}
		}		
		if("edit".equalsIgnoreCase(theForm.getAction())){
			try{
				String productIdValue=request.getParameter("productIdValue");
				if(productIdValue!=null && productIdValue.trim().length()!=0){
					Product product=dropShippingHelper.getProductDetail(productIdValue);
					theForm.setSupplierPartNum(product.getSupplierPartNumber());
					theForm.setManufacturerPartNum(product.getManufacturerPartNumber());
					theForm.setManufacturerName(product.getManufacturerName());
					theForm.setDescription(product.getDescription());
					theForm.setPrice(product.getPrice());
					theForm.setUnitofmeasure(product.getUom());
					theForm.setPkgqty(""+product.getPkgQty());
					theForm.setImageurl(product.getImageUrl());
					theForm.setUpc(product.getUpc());
					request.setAttribute("productIdValue", product.getProductId());
					request.setAttribute("editProduct", "editProduct");
				}
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("update".equalsIgnoreCase(theForm.getAction())){
			try{
				String productIdValue=request.getParameter("productIdValue");
				if(productIdValue!=null && productIdValue.trim().length()!=0){
					dropShippingHelper.updateProduct(Long.parseLong(productIdValue),theForm.getSupplierPartNum(), theForm.getManufacturerPartNum(), theForm.getManufacturerName(), theForm.getDescription(), theForm.getUnitofmeasure(), theForm.getPkgqty(), theForm.getImageurl(), theForm.getPrice(), theForm.getUpc());
				}
				theForm.setAction("manageProducts");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("delete".equalsIgnoreCase(theForm.getAction())){
			try{
				String productIdValue=request.getParameter("productIdValue");
				if(productIdValue!=null && productIdValue.trim().length()!=0){
					dropShippingHelper.deleteProduct(productIdValue);
				}
				theForm.setAction("manageProducts");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		
		if("manageProducts".equalsIgnoreCase(theForm.getAction())){
			try{
				ArrayList productsList=dropShippingHelper.getAllProducts();
				if(productsList!=null && productsList.size()!=0){
					request.setAttribute("productList",productsList);
				}
				return mapping.findForward("manageProducts");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		return mapping.findForward("success");
	}
}
