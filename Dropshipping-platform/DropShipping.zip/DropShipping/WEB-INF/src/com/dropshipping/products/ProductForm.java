package com.dropshipping.products;

import org.apache.struts.action.ActionForm;

public class ProductForm extends ActionForm{
	private String action;
	private String supplierPartNum;
	private String manufacturerPartNum;
	private String manufacturerName;
	private String description;
	private String unitofmeasure; 
	private String pkgqty;
	private String imageurl; 
	private String price;
	private String upc;
	private String categoryId;
	
	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getSupplierPartNum() {
		return supplierPartNum;
	}

	public void setSupplierPartNum(String supplierPartNum) {
		this.supplierPartNum = supplierPartNum;
	}

	public String getManufacturerPartNum() {
		return manufacturerPartNum;
	}

	public void setManufacturerPartNum(String manufacturerPartNum) {
		this.manufacturerPartNum = manufacturerPartNum;
	}

	public String getManufacturerName() {
		return manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUnitofmeasure() {
		return unitofmeasure;
	}

	public void setUnitofmeasure(String unitofmeasure) {
		this.unitofmeasure = unitofmeasure;
	}

	public String getPkgqty() {
		return pkgqty;
	}

	public void setPkgqty(String pkgqty) {
		this.pkgqty = pkgqty;
	}

	public String getImageurl() {
		return imageurl;
	}

	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}	

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
}
