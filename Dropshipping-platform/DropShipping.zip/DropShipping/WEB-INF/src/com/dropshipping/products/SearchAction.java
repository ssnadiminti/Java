package com.dropshipping.products;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.Product;
import com.dropshipping.helper.DropShippingHelper;

public class SearchAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		SearchForm theForm = (SearchForm) form;
		DropShippingHelper roboHelper=new DropShippingHelper();
		if("search".equalsIgnoreCase(theForm.getAction())){
			try{
				String search=request.getParameter("search");
				if(search!=null && search.trim().length()!=0){
					ArrayList productsList=roboHelper.getSearchProducts(search);
					if(productsList!=null && productsList.size()!=0){
						request.setAttribute("productList",productsList);
					}
				}
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		
		if("categorySearch".equalsIgnoreCase(theForm.getAction())){
			try{
				String categoryId=request.getParameter("categoryId");
				if(categoryId!=null && categoryId.trim().length()!=0){
					ArrayList productsList=roboHelper.getCategoryProducts(categoryId);
					if(productsList!=null && productsList.size()!=0){
						request.setAttribute("productList",productsList);
					}
				}
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		
		if("productDetail".equalsIgnoreCase(theForm.getAction())){
			try{
				String productId=request.getParameter("productIdValue");
				if(productId!=null && productId.trim().length()!=0){
					Product product=roboHelper.getProductDetail(productId);
					if(productId!=null){
						double productRating=roboHelper.getReviewItem(productId);
						request.setAttribute("productRating",String.format("%.2f", productRating));
						request.setAttribute("product",product);
					}
				}
				return mapping.findForward("successProductDetail");
			}catch (Exception e){
				e.printStackTrace();
			}
			return mapping.findForward("successProductDetail");
		}
		if("reviewProduct".equalsIgnoreCase(theForm.getAction())){
			try{
				String supplierPartNumber=request.getParameter("supplierPartNumber");
				String itemId=request.getParameter("itemId");
				request.setAttribute("supplierPartNumber",supplierPartNumber);
				request.setAttribute("itemId",itemId);
				request.setAttribute("reviewProduct","reviewProduct");
				return mapping.findForward("reviewProduct");
			}catch (Exception e){
				e.printStackTrace();
			}
			return mapping.findForward("reviewProduct");
		}
		if("saveReview".equalsIgnoreCase(theForm.getAction())){
			try{
				String itemId=request.getParameter("itemId");
				roboHelper.insertReviewItem(itemId, theForm.getReviewername(), theForm.getRevieweremail(), theForm.getReviewertitle(), theForm.getReviewerlocation(), theForm.getReviewerrate(), theForm.getReview());
				request.setAttribute("saveReviewProduct","saveReviewProduct");
				return mapping.findForward("reviewProduct");
			}catch (Exception e){
				e.printStackTrace();
			}
			return mapping.findForward("reviewProduct");
		}
		return mapping.findForward("success");
	}
}
