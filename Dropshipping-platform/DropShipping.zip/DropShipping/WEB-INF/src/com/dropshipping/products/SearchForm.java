package com.dropshipping.products;

import org.apache.struts.action.ActionForm;

public class SearchForm extends ActionForm{
	private String action;
	private Long itemId;
	private String reviewername;
	private String revieweremail;
	private String reviewertitle;
	private String reviewerlocation;
	private String reviewerrate;
	private String review;
	
	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getReviewername() {
		return reviewername;
	}

	public void setReviewername(String reviewername) {
		this.reviewername = reviewername;
	}

	public String getRevieweremail() {
		return revieweremail;
	}

	public void setRevieweremail(String revieweremail) {
		this.revieweremail = revieweremail;
	}

	public String getReviewertitle() {
		return reviewertitle;
	}

	public void setReviewertitle(String reviewertitle) {
		this.reviewertitle = reviewertitle;
	}

	public String getReviewerlocation() {
		return reviewerlocation;
	}

	public void setReviewerlocation(String reviewerlocation) {
		this.reviewerlocation = reviewerlocation;
	}

	public String getReviewerrate() {
		return reviewerrate;
	}

	public void setReviewerrate(String reviewerrate) {
		this.reviewerrate = reviewerrate;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
	
}
