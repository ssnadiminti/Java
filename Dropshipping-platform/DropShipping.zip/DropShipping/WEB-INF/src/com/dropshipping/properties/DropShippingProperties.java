package com.dropshipping.properties;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;



public class DropShippingProperties {
	public static String get(String key){
	    Properties properties = new Properties();
	    InputStream inp = null;
	    try{
	      inp = DropShippingProperties.class.getResourceAsStream("GlobalDataProperties.properties");//the images paths are placed in this file.
	      properties.load(inp);
	    }
	    catch(FileNotFoundException e){
	      System.err.println("FileNotFoundException");
	    }
	    catch(IOException e){
	      System.err.println("IOException");
	    }
	    finally{
	    	try{
	    		if(inp != null)inp.close();
	    	}catch(Exception e){e.printStackTrace();}
	    }
	    String value = properties.getProperty(key);
	    return(value != null ? value : "");
	}
}
