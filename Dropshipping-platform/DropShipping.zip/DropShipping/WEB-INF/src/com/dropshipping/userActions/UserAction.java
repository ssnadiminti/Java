package com.dropshipping.userActions;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.User;
import com.dropshipping.helper.DropShippingHelper;
import com.dropshipping.helper.Tools;

public class UserAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		UserForm theForm = (UserForm) form;
		HttpSession session=request.getSession();
		DropShippingHelper roboHelper=new DropShippingHelper();
		if("add".equalsIgnoreCase(theForm.getAction())){
			try{
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}		
		if("update".equalsIgnoreCase(theForm.getAction())){
			try{
				Long userId=(Long)session.getAttribute("userId");
				if(userId!=null){
					User user=roboHelper.getUserDetails(userId);
					if(user!=null){
						theForm.setFirstName(user.getFirstName());
						theForm.setLastName(user.getLastName());
						theForm.setSSN(user.getSSN());
						theForm.setMobile(user.getMobile());
						request.setAttribute("editUser", "editUser");
					}
				}			
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}		
		if("save".equalsIgnoreCase(theForm.getAction())){
			try{
				roboHelper.insertUser(theForm.getFirstName(), theForm.getLastName(), theForm.getUserEmail(), Tools.cross(theForm.getUserPassword(),"23453452345"), theForm.getMobile(), theForm.getSSN(), "CUSTOMER");
				theForm.setAction("manageUsers");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("saveUpdate".equalsIgnoreCase(theForm.getAction())){
			try{
				Long userId=(Long)session.getAttribute("userId");
				if(userId!=null){
					roboHelper.updateUser(userId,theForm.getFirstName(), theForm.getLastName(), theForm.getMobile(), theForm.getSSN());
				}				
				return mapping.findForward("saveUpdate");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("delete".equalsIgnoreCase(theForm.getAction())){
			try{
				String userIdValue=request.getParameter("userIdValue");
				if(userIdValue!=null && userIdValue.trim().length()!=0){
					roboHelper.deleteUser(userIdValue);
				}
				theForm.setAction("manageUsers");
			}catch (Exception e){
				e.printStackTrace();
			}
		}		
		if("manageUsers".equalsIgnoreCase(theForm.getAction())){
			try{
				ArrayList usersList=roboHelper.getAllUsers();
				if(usersList!=null && usersList.size()!=0){
					request.setAttribute("usersList",usersList);
				}
				return mapping.findForward("manageUsers");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		return mapping.findForward("success");
	}
}