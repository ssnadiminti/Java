// JavaScript Document
$(document).ready(function() {
	$(".tab-quick ul li a").click(function() {
		$('.tab-quick ul li a').removeClass();
		$(this).addClass('select');
		var index = $('.tab-quick ul li a').index($(this));
		$('.tab-details-quick > div').hide();
		$('.tab-details-quick > div').filter(':eq(' + index + ')').show();
  	});
});

$(document).ready(function() {
	$(".tab-quick2 ul li a").click(function() {
		$('.tab-quick2 ul li a').removeClass();
		$(this).addClass('select');
		var index = $('.tab-quick2 ul li a').index($(this));
		$('.tab-details-quick2 > div').hide();
		$('.tab-details-quick2 > div').filter(':eq(' + index + ')').show();
  	});
});