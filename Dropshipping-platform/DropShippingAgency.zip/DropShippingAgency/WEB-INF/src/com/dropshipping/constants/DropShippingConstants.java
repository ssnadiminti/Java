package com.dropshipping.constants;

import com.dropshipping.properties.DropShippingProperties;

public class DropShippingConstants {
	public static final String path = DropShippingProperties.get("basePath");
}
