package com.dropshipping.helper;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import com.bean.Product;
import com.bean.User;

public class DropShippingAgencyHelper{
	public static Connection getNonPooledConnection() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String host = "jdbc:mysql://localhost/easyshopping";
            String uName = "root";
            String uPass= "unoscm2010";
            conn =DriverManager.getConnection(host,uName,uPass);  
		} catch (Exception e) {
			e.printStackTrace();
		}
		return (conn);
	}

	public void insertUser(String firstName,String lastName,String emailId,String password,String phoneNo,String ssn,String userRole,String companyname){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "insert into agencyusers (firstname,lastname,emailid,password,phoneno,ssn,companyname,userrole,deleteflag) values ('"+firstName+"','"+lastName+"','"+emailId+"','"+password+"','"+phoneNo+"','"+ssn+"','"+companyname+"','"+userRole+"','N')";
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public Long maxUserId(){
		Connection conn=null;
		Statement stmt=null;
		Long userId=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select max(userid) from agencyusers");
	    		if(rs!=null){
	    			while(rs.next()){
	    				userId=rs.getLong(1);
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}	
        return userId;
    }
	
	public void updateUser(Long userId,String firstName,String lastName,String phoneNo,String ssn){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "update users set firstname='"+firstName+"',lastname='"+lastName+"',phoneno='"+phoneNo+"',ssn='"+ssn+"' where userid="+userId;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public String orderNumber() {
		String number=null;
		try{
			number=getOrderNumber(12);
			boolean val=checkOrderNumber(number);
			if(val==true){
				orderNumber();
			}
			return number;
		}catch(Exception e){
			e.printStackTrace();
		}
		return number;
	}
	public String getOrderNumber(int len){
		char[] pw=new char[len];
		try{  			
			int c='A';
			int r1=0;
			for(int i=0;i<len;i++){
				r1=(int)(Math.random()*3);
				switch(r1){
				case 0:c='0'+(int)(Math.random()*10);break;
				case 1:c='a'+(int)(Math.random()*26);break;
				case 2:c='A'+(int)(Math.random()*26);break;
			}
			pw[i]=(char)c;
		  }
		}catch(Exception e){
			e.printStackTrace();
		}
		return new String(pw);
	}
	
	public void insertOrder(Long userId,String createdDate,String checkoutFlag,String orderNumber,String tempPaymentMethod){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "insert into orders (userid ,createddate ,checkoutflag ,orderuniqueid ,paymentmethod) values ("+userId+",'"+createdDate+"','"+checkoutFlag+"','"+orderNumber+"','"+tempPaymentMethod+"')";
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void updateOrder(Long orderId,String paymentMethod,String guestEmail,Long userId){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            if(userId!=null){
	            	String sql = "update orders set userid="+userId+",paymentmethod='"+paymentMethod+"',checkoutflag='Y' where orderid="+orderId;
	            	stmt.executeUpdate(sql);
	            }else{
	            	String sql = "update orders set guestemail='"+guestEmail+"',paymentmethod='"+paymentMethod+"',checkoutflag='Y' where orderid="+orderId;
	            	stmt.executeUpdate(sql);
	            }
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void insertOrderItem(Long orderId,String price,int quantity,String spplierPartNum,String mfrPartNum,String mfrName,String description,String uom,int pkgQty,String imageUrl){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "insert into orderitems (orderid ,price ,orderqty ,supplierpartnum ,manufacturerpartnum ,manufacturername ,description ,uom ,pkgqty , imageurl) values ("+orderId+","+new BigDecimal(price)+","+quantity+",'"+spplierPartNum+"','"+mfrPartNum+"','"+mfrName+"','"+description+"','"+uom+"',"+pkgQty+",'"+imageUrl+"')";
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void deleteOrderItem(String orderItemsId){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "delete from orderitems where orderitemid="+orderItemsId;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public boolean checkOrderNumber(String orderNumber){
		Connection conn=null;
		Statement stmt=null;
		boolean check=false;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from orders where orderuniqueid='"+orderNumber+"'");
	    		if(rs!=null){
	    			while(rs.next()){
	    				check=true;
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return check;
    }
	
	public Long getOrderId(String orderNumber){
		Connection conn=null;
		Statement stmt=null;
		Long orderId=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select orderid from orders where orderuniqueid='"+orderNumber+"'");
	    		if(rs!=null){
	    			while(rs.next()){
	    				orderId=new Long(rs.getInt("orderid"));
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return orderId;
    }
	
	public void deleteProduct(String productIdValue){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	            String deletedDate = sdf.format(new Date());
	            String sql = "update agencycatalogitems set deleteflag='Y',deleteddate='"+deletedDate+"' where itemid="+productIdValue;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void deleteUser(String userIdValue){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "update users set deleteflag='Y' where userid="+userIdValue;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void deleteCategory(String categoryIdValue){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "update category set deleteflag='Y' where categoryid="+categoryIdValue;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void updateCartProduct(Long orderItemId,int qty){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            String sql = "update orderitems set orderqty="+qty+" where orderitemid="+orderItemId;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void insertProduct(String supplierPartNum,String manufacturerPartNum,String manufacturerName,String description,String unitofmeasure,String pkgqty,String imageurl,String price,String upc,String categoryId){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	            String createdDate = sdf.format(new Date());
	            String sql = "insert into agencycatalogitems (supplierpartnum,manufacturerpartnum,manufacturername,description,unitofmeasure,pkgqty,imageurl,price,upc,deleteflag,addeddate,categoryname) values ('"+supplierPartNum+"','"+manufacturerPartNum+"','"+manufacturerName+"','"+description+"','"+unitofmeasure+"',"+pkgqty+",'"+imageurl+"','"+new BigDecimal(price)+"','"+upc+"','N','"+createdDate+"','"+categoryId+"')";
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void insertOrUpdateRetailerItems(Long userid,String itemid,String qty){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select qty from retaileritems where itemid="+itemid+" and userid="+userid);
	    		int qtyValue=0;
	            if(rs!=null){
	    			while(rs.next()){
	    				qtyValue=rs.getInt("qty");
	    			}
	    		}
	            if(qtyValue==0){
		            String sql = "insert into retaileritems (userid,itemid,qty) values ("+userid+","+itemid+","+qty.trim()+")";
		            stmt.executeUpdate(sql);
	            }else{
	            	String sql = "update retaileritems set qty="+(qtyValue+Integer.parseInt(qty.trim()))+" where itemid="+itemid+" and userid="+userid;
		            stmt.executeUpdate(sql);
	            }
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void insertCategory(String categoryName){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );	            
	            String sql = "insert into category (categoryname,deleteflag) values ('"+categoryName+"','N')";
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void updateCategory(Long categoryId,String categoryName){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement();
	            String sql = "update category set categoryname='"+categoryName+"' where categoryid="+categoryId;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public void updateProduct(Long productId,String supplierPartNum,String manufacturerPartNum,String manufacturerName,String description,String unitofmeasure,String pkgqty,String imageurl,String price,String upc){
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	            String createdDate = sdf.format(new Date());
	            String sql = "update agencycatalogitems set supplierpartnum='"+supplierPartNum+"',manufacturerpartnum='"+manufacturerPartNum+"',manufacturername='"+manufacturerName+"',description='"+description+"',unitofmeasure='"+unitofmeasure+"',pkgqty="+pkgqty+",imageurl='"+imageurl+"',price='"+new BigDecimal(price)+"',upc='"+upc+"',deleteflag='N',updateddate='"+createdDate+"' where itemid="+productId;
	            stmt.executeUpdate(sql);
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}		
    }
	
	public ArrayList getAllProducts(){
		Connection conn=null;
		Statement stmt=null;
		ArrayList productList=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from agencycatalogitems where deleteflag='N'");
	    		if(rs!=null){
	    			productList=new ArrayList();
	    			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    			while (rs.next()) {
	    				Product product=new Product();
	    				product.setProductId(new Long(rs.getInt("itemid")));
	    				product.setSupplierPartNumber(rs.getString("supplierpartnum"));
	    				product.setManufacturerPartNumber(rs.getString("manufacturerpartnum"));
	    				product.setManufacturerName(rs.getString("manufacturername"));
	    				product.setDescription(rs.getString("description"));
	    				product.setUom(rs.getString("unitofmeasure"));
	    				product.setPkgQty(rs.getInt("pkgqty"));
	    				product.setImageUrl(rs.getString("imageurl"));
	    				product.setPrice(""+rs.getBigDecimal("price"));
	    				product.setUpc(rs.getString("upc"));
	    				product.setDeleteFlag(rs.getString("deleteflag"));
	    				product.setAddedDate(sdf.format(rs.getDate("addeddate")));
	    				productList.add(product);    				
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return productList;
    }
	
	public ArrayList getMyProducts(Long userId){
		Connection conn=null;
		Statement stmt=null;
		ArrayList productList=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from agencycatalogitems aci,retaileritems ri where aci.deleteflag='N' and aci.itemid=ri.itemid and ri.userid="+userId);
	    		if(rs!=null){
	    			productList=new ArrayList();
	    			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    			while (rs.next()) {
	    				Product product=new Product();
	    				product.setProductId(new Long(rs.getInt("itemid")));
	    				product.setSupplierPartNumber(rs.getString("supplierpartnum"));
	    				product.setManufacturerPartNumber(rs.getString("manufacturerpartnum"));
	    				product.setManufacturerName(rs.getString("manufacturername"));
	    				product.setDescription(rs.getString("description"));
	    				product.setUom(rs.getString("unitofmeasure"));
	    				product.setPkgQty(rs.getInt("qty"));
	    				product.setImageUrl(rs.getString("imageurl"));
	    				product.setPrice(""+rs.getBigDecimal("price"));
	    				product.setUpc(rs.getString("upc"));
	    				product.setDeleteFlag(rs.getString("deleteflag"));
	    				product.setAddedDate(sdf.format(rs.getDate("addeddate")));
	    				product.setCategoryname(rs.getString("categoryname"));
	    				productList.add(product);    				
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return productList;
    }
	
	public ArrayList getAllUsers(){
		Connection conn=null;
		Statement stmt=null;
		ArrayList usersList=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from users where userrole='CUSTOMER' and deleteflag='N'");
	    		if(rs!=null){
	    			usersList=new ArrayList();
	    			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    			while (rs.next()) {
	    				User user=new User();
	    				user.setUserId(new Long(rs.getInt("userid")));
	    				user.setFirstName(rs.getString("firstname"));
	    				user.setLastName(rs.getString("lastname"));
	    				user.setUserEmail(rs.getString("emailid"));
	    				user.setMobile(rs.getString("phoneno"));
	    				user.setSSN(rs.getString("SSN"));
	    				usersList.add(user);    				
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return usersList;
    }
	
	public User getUserDetails(Long userId){
		Connection conn=null;
		Statement stmt=null;
		User user=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from users where userid="+userId+" and deleteflag='N'");
	    		if(rs!=null){
	    			while (rs.next()) {
	    				user=new User();
	    				user.setUserId(new Long(rs.getInt("userid")));
	    				user.setFirstName(rs.getString("firstname"));
	    				user.setLastName(rs.getString("lastname"));
	    				user.setUserEmail(rs.getString("emailid"));
	    				user.setMobile(rs.getString("phoneno"));
	    				user.setSSN(rs.getString("SSN"));		
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return user;
    }
	
	public ArrayList getSearchProducts(String searchText){
		Connection conn=null;
		Statement stmt=null;
		ArrayList productList=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from agencycatalogitems where (supplierpartnum  like '%"+searchText+"%' or manufacturerpartnum like '%"+searchText+"%' or description like '%"+searchText+"%' or manufacturername like '%"+searchText+"%' or upc like '%"+searchText+"%') and deleteflag='N' ");
	    		if(rs!=null){
	    			productList=new ArrayList();
	    			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    			while (rs.next()) {
	    				Product product=new Product();
	    				product.setProductId(new Long(rs.getInt("itemid")));
	    				product.setSupplierPartNumber(rs.getString("supplierpartnum"));
	    				product.setManufacturerPartNumber(rs.getString("manufacturerpartnum"));
	    				product.setManufacturerName(rs.getString("manufacturername"));
	    				product.setDescription(rs.getString("description"));
	    				product.setUom(rs.getString("unitofmeasure"));
	    				product.setPkgQty(rs.getInt("pkgqty"));
	    				product.setImageUrl(rs.getString("imageurl"));
	    				product.setPrice(""+rs.getBigDecimal("price"));
	    				product.setUpc(rs.getString("upc"));
	    				product.setDeleteFlag(rs.getString("deleteflag"));
	    				product.setAddedDate(sdf.format(rs.getDate("addeddate")));
	    				productList.add(product);    				
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return productList;
    }
	
	public ArrayList getCategoryProducts(String categoryId){
		Connection conn=null;
		Statement stmt=null;
		ArrayList productList=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from agencycatalogitems where categoryId="+categoryId+" and deleteflag='N'");
	    		if(rs!=null){
	    			productList=new ArrayList();
	    			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    			while (rs.next()) {
	    				Product product=new Product();
	    				product.setProductId(new Long(rs.getInt("itemid")));
	    				product.setSupplierPartNumber(rs.getString("supplierpartnum"));
	    				product.setManufacturerPartNumber(rs.getString("manufacturerpartnum"));
	    				product.setManufacturerName(rs.getString("manufacturername"));
	    				product.setDescription(rs.getString("description"));
	    				product.setUom(rs.getString("unitofmeasure"));
	    				product.setPkgQty(rs.getInt("pkgqty"));
	    				product.setImageUrl(rs.getString("imageurl"));
	    				product.setPrice(""+rs.getBigDecimal("price"));
	    				product.setUpc(rs.getString("upc"));
	    				product.setDeleteFlag(rs.getString("deleteflag"));
	    				product.setAddedDate(sdf.format(rs.getDate("addeddate")));
	    				productList.add(product);    				
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return productList;
    }
	
	public Product getProductDetail(String productId){
		Connection conn=null;
		Statement stmt=null;
		Product product=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select * from agencycatalogitems where itemid="+productId+" and deleteflag='N'");
	    		if(rs!=null){
	    			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	    			while (rs.next()) {
	    				product=new Product();
	    				product.setProductId(new Long(rs.getInt("itemid")));
	    				product.setSupplierPartNumber(rs.getString("supplierpartnum"));
	    				product.setManufacturerPartNumber(rs.getString("manufacturerpartnum"));
	    				product.setManufacturerName(rs.getString("manufacturername"));
	    				product.setDescription(rs.getString("description"));
	    				product.setUom(rs.getString("unitofmeasure"));
	    				product.setPkgQty(rs.getInt("pkgqty"));
	    				product.setImageUrl(rs.getString("imageurl"));
	    				product.setPrice(""+rs.getBigDecimal("price"));
	    				product.setUpc(rs.getString("upc"));
	    				product.setDeleteFlag(rs.getString("deleteflag"));
	    				product.setAddedDate(sdf.format(rs.getDate("addeddate")));   				
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return product;
    }
	
	public String totalCartPrice(String orderNumber){
		Connection conn=null;
		Statement stmt=null;
		String totalPrice=null;
		try{
			conn =getNonPooledConnection();
			if(conn!=null){
	            stmt = conn.createStatement( );
	            ResultSet rs = stmt.executeQuery("select sum(price*orderqty) from orderitems where orderid in (select orderid from orders where orderuniqueid='"+orderNumber+"')");
	    		if(rs!=null){
	    			while (rs.next()) {
	    				totalPrice=""+rs.getBigDecimal(1);
	    			}
	    		}
			}
        }catch(SQLException err){
        	err.printStackTrace();
        }finally{
		     try{
		    	 if(stmt!=null){
			    	 stmt.close();
			     }
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		}
        return totalPrice;
    }
	
	public static String getUsersEmail(String email) throws Exception{
		String userEmail=null;
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
    		stmt = conn.createStatement();
    		ResultSet rs = stmt.executeQuery("select userid from agencyusers where emailid='"+ email+ "' and deleteflag='N'");
			while (rs.next()) {
				userEmail = ""+rs.getInt(1);
				System.out.println(userEmail);
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
		}
		finally{
		     if(stmt!=null){
		    	 stmt.close();
		     }
		     try{
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		   }
		return userEmail;
	}
	
	public static User getUserData(String email,String password) throws Exception{
		User user=null;
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
    		stmt = conn.createStatement();
    		ResultSet rs = stmt.executeQuery("select * from agencyusers where emailid='"+ email+ "' and password='"+password+"' and deleteflag='N'");
			while (rs.next()) {
				user = new User();
				user.setUserId(new Long(rs.getInt("userid")));
				user.setFirstName(rs.getString("firstname"));
				user.setLastName(rs.getString("lastname"));
				user.setUserEmail(rs.getString("emailid"));
				user.setMobile(rs.getString("phoneno"));
				user.setSSN(rs.getString("ssn"));
				user.setUserRole(rs.getString("userrole"));
				System.out.println(rs.getString(1));
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
		}
		finally{
		     if(stmt!=null){
		    	 stmt.close();
		     }
		     try{
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		   }
		return user;
	}
	public static User getUserDataFromEmail(String email) throws Exception{
		User user=null;
		Connection conn=null;
		Statement stmt=null;
		try{
			conn =getNonPooledConnection();
    		stmt = conn.createStatement();
    		ResultSet rs = stmt.executeQuery("select * from agencyusers where emailid='"+ email+ "' and deleteflag='N'");
			while (rs.next()) {
				user = new User();
				user.setUserId(new Long(rs.getInt("userid")));
				user.setFirstName(rs.getString("firstname"));
				user.setLastName(rs.getString("lastname"));
				user.setLastName(rs.getString("lastname"));
				user.setPassword(rs.getString("password"));
				user.setMobile(rs.getString("phoneno"));
				user.setSSN(rs.getString("ssn"));
				user.setUserRole(rs.getString("userrole"));
				System.out.println(rs.getString(1));
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
		}
		finally{
		     if(stmt!=null){
		    	 stmt.close();
		     }
		     try{
		         if(conn!=null)
		            conn.close();
		      }catch(Exception e){
		         e.printStackTrace();
		      }
		   }
		return user;
	}
}