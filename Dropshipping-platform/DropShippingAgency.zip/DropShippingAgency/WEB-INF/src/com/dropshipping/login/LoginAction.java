package com.dropshipping.login;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.User;
import com.dropshipping.helper.DropShippingAgencyHelper;
import com.dropshipping.helper.Tools;




public class LoginAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LoginForm loginForm = (LoginForm) form;		
		ActionErrors actionError = new ActionErrors();
		String action = request.getParameter("action");
		String userMail = loginForm.getEmail();
		String password = loginForm.getPassword();
		HttpSession session=request.getSession();
		DropShippingAgencyHelper helper=new DropShippingAgencyHelper();
		System.out.println(action+"     "+userMail+"      "+password);		
		try{
			if(action!=null && action.trim().length()!=0 && action.equalsIgnoreCase("checkMail")){
				if(userMail!=null && userMail.trim().length()!=0 && password!=null && password.trim().length()!=0){								
			    	String result = "";
			    	User user=helper.getUserData(userMail, Tools.cross(password, "23453452345"));
			    	if(user==null){
			    		result = "failure";
			    	}else{
				    	result = "success";
						session.setAttribute("email", user.getUserEmail());
						session.setAttribute("userRole",user.getUserRole());
						session.setAttribute("userId",new Long(user.getUserId()));
						session.setAttribute("userAccountNumber",new Long(10000+user.getUserId()));
			    	}
			    	response.getWriter().write(result);
					return null;
				}	
			}
			if(action!=null && action.trim().length()!=0 && action.equalsIgnoreCase("myAccount")){
				String userType=(String)session.getAttribute("userRole");
				if(userType!=null && userType.trim().length()!=0){
					return mapping.findForward("successUser");
				}
			}
			if(action!=null && action.trim().length()!=0 && action.equalsIgnoreCase("home")){
				return mapping.findForward("home");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return mapping.findForward("success");
	}
}
