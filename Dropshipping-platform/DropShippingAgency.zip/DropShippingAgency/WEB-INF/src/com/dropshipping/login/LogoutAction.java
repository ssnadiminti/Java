package com.dropshipping.login;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dropshipping.constants.DropShippingConstants;

public class LogoutAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {		
		try{
			request.getSession().invalidate();
			response.sendRedirect(DropShippingConstants.path);
			return null;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
}
