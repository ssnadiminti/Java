package com.dropshipping.products;

import java.util.ArrayList;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bean.Product;
import com.dropshipping.helper.DropShippingAgencyHelper;

public class ProductAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ProductForm theForm = (ProductForm) form;
		DropShippingAgencyHelper dropShippingHelper=new DropShippingAgencyHelper();
		HttpSession session=request.getSession();
		if("add".equalsIgnoreCase(theForm.getAction())){
			try{
				theForm.setSupplierPartNum("");
				theForm.setManufacturerPartNum("");
				theForm.setManufacturerName("");
				theForm.setDescription("");
				theForm.setPrice("");
				theForm.setUnitofmeasure("");
				theForm.setPkgqty("");
				theForm.setImageurl("");
				theForm.setUpc("");				
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("save".equalsIgnoreCase(theForm.getAction())){
			try{
				System.out.println(theForm.getSupplierPartNum()+" "+theForm.getManufacturerName());
				dropShippingHelper.insertProduct(theForm.getSupplierPartNum(), theForm.getManufacturerPartNum(), theForm.getManufacturerName(), theForm.getDescription(), theForm.getUnitofmeasure(), theForm.getPkgqty(), theForm.getImageurl(), theForm.getPrice(), theForm.getUpc(),theForm.getCategoryId());
				theForm.setAction("manageProducts");
			}catch (Exception e){
				e.printStackTrace();
			}
		}		
		if("edit".equalsIgnoreCase(theForm.getAction())){
			try{
				String productIdValue=request.getParameter("productIdValue");
				if(productIdValue!=null && productIdValue.trim().length()!=0){
					Product product=dropShippingHelper.getProductDetail(productIdValue);
					theForm.setSupplierPartNum(product.getSupplierPartNumber());
					theForm.setManufacturerPartNum(product.getManufacturerPartNumber());
					theForm.setManufacturerName(product.getManufacturerName());
					theForm.setDescription(product.getDescription());
					theForm.setPrice(product.getPrice());
					theForm.setUnitofmeasure(product.getUom());
					theForm.setPkgqty(""+product.getPkgQty());
					theForm.setImageurl(product.getImageUrl());
					theForm.setUpc(product.getUpc());
					request.setAttribute("productIdValue", product.getProductId());
					request.setAttribute("editProduct", "editProduct");
				}
				return mapping.findForward("success");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("update".equalsIgnoreCase(theForm.getAction())){
			try{
				String productIdValue=request.getParameter("productIdValue");
				if(productIdValue!=null && productIdValue.trim().length()!=0){
					dropShippingHelper.updateProduct(Long.parseLong(productIdValue),theForm.getSupplierPartNum(), theForm.getManufacturerPartNum(), theForm.getManufacturerName(), theForm.getDescription(), theForm.getUnitofmeasure(), theForm.getPkgqty(), theForm.getImageurl(), theForm.getPrice(), theForm.getUpc());
				}
				theForm.setAction("manageProducts");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		if("delete".equalsIgnoreCase(theForm.getAction())){
			try{
				String productIdValue=request.getParameter("productIdValue");
				if(productIdValue!=null && productIdValue.trim().length()!=0){
					dropShippingHelper.deleteProduct(productIdValue);
				}
				theForm.setAction("manageProducts");
			}catch (Exception e){
				e.printStackTrace();
			}
		}
		
		if("manageProducts".equalsIgnoreCase(theForm.getAction())){
			try{
				ArrayList productsList=dropShippingHelper.getAllProducts();
				if(productsList!=null && productsList.size()!=0){
					request.setAttribute("productList",productsList);
				}
				return mapping.findForward("manageProducts");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		if("submitBuyProducts".equalsIgnoreCase(theForm.getAction())){
			try{
				Long userId=(Long)session.getAttribute("userId");
				if(userId!=null){
					String check[]=request.getParameterValues("buyqtycheck");
					String buyqty[]=request.getParameterValues("buyqty");
					String itemid[]=request.getParameterValues("itemid");
					if(check!=null){
						for(int i=0;i<check.length;i++){
							dropShippingHelper.insertOrUpdateRetailerItems(userId,itemid[Integer.parseInt(check[i])],buyqty[Integer.parseInt(check[i])]);
						}
					}
				}
				theForm.setAction("manageMyProducts");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		if("manageMyProducts".equalsIgnoreCase(theForm.getAction())){
			try{
				Long userId=(Long)session.getAttribute("userId");
				if(userId!=null){
					ArrayList productsList=dropShippingHelper.getMyProducts(userId);
					if(productsList!=null && productsList.size()!=0){
						request.setAttribute("productList",productsList);
					}
				}
				return mapping.findForward("manageMyProducts");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		if("download".equalsIgnoreCase(theForm.getAction())){
			try{
				String contentType = "application/vnd.ms-excel";
				XSSFWorkbook wb = new XSSFWorkbook();
				XSSFCellStyle cellStyle = wb.createCellStyle(); 
				XSSFFont hssfont =wb.createFont();
				hssfont.setFontName(HSSFFont.FONT_ARIAL);
				hssfont.setFontHeightInPoints((short) 10);
				hssfont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				cellStyle = wb.createCellStyle();  
				cellStyle.setWrapText(true);
				cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				cellStyle.setFillForegroundColor(HSSFColor.GREEN.index);
				cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);  
				cellStyle.setBorderTop((short) 1); // single line border
				cellStyle.setBorderLeft((short) 1);
				cellStyle.setBorderRight((short) 1);
				cellStyle.setBorderBottom((short) 1); // single line border
				cellStyle.setFont(hssfont);
				XSSFCellStyle cellStyle1 = wb.createCellStyle();  
				cellStyle1 = wb.createCellStyle();  
				cellStyle1.setWrapText(true);
				cellStyle1.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				cellStyle1.setFillForegroundColor(HSSFColor.YELLOW.index);  
				cellStyle1.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);  
				cellStyle1.setBorderTop((short) 1); // single line border
				cellStyle1.setBorderLeft((short) 1);
				cellStyle1.setBorderRight((short) 1);
				cellStyle1.setBorderBottom((short) 1); // single line border
				cellStyle1.setFont(hssfont);
				XSSFSheet sheet = wb.createSheet("Reports");
				sheet.setColumnWidth(0, 7000);
				sheet.setColumnWidth(1, 7000);
				sheet.setColumnWidth(2, 7000);
				sheet.setColumnWidth(3, 7000);
				sheet.setColumnWidth(4, 7000);
				sheet.setColumnWidth(5, 7000);
				sheet.setColumnWidth(6, 7000);
				sheet.setColumnWidth(7, 7000);
				sheet.setColumnWidth(8, 7000);
				sheet.setColumnWidth(9, 7000);
				XSSFRow row=sheet.createRow((short)0);
				XSSFCellStyle cs=wb.createCellStyle();
				cs.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				cs.setFillForegroundColor(HSSFColor.YELLOW.index);
				cs.setBorderTop((short) 1);
				cs.setBorderLeft((short) 1);
				cs.setBorderRight((short) 1);
				cs.setBorderBottom((short) 1);
				XSSFCell cell2B = row.createCell(0);  
				cell2B.setCellValue("My Products");
				
				XSSFRow row4=sheet.createRow((short)4);
				XSSFCell cell2=row4.createCell(0);
				cell2.setCellValue("supplierPartNumber");
				cell2.setCellStyle(cellStyle);
				XSSFCell cell3=row4.createCell(1);
				cell3.setCellValue("manufacturerPartNumber");
				cell3.setCellStyle(cellStyle);
				XSSFCell cell4=row4.createCell(2);
				cell4.setCellValue("manufacturerName");
				cell4.setCellStyle(cellStyle);
				XSSFCell cell5=row4.createCell(3);
				cell5.setCellValue("description");
				cell5.setCellStyle(cellStyle);
				XSSFCell cell6=row4.createCell(4);
				cell6.setCellValue("imageUrl");
				cell6.setCellStyle(cellStyle);
				XSSFCell cell7=row4.createCell(5);
				cell7.setCellValue("uom");
				cell7.setCellStyle(cellStyle);
				XSSFCell cell8=row4.createCell(6);
				cell8.setCellValue("price");
				cell8.setCellStyle(cellStyle);
				cell8=row4.createCell(7);
				cell8.setCellValue("Buy Order Qty");
				cell8.setCellStyle(cellStyle);
				cell8=row4.createCell(8);
				cell8.setCellValue("upc");
				cell8.setCellStyle(cellStyle);
				cell8=row4.createCell(9);
				cell8.setCellValue("category name");
				cell8.setCellStyle(cellStyle);
				
				Long userId=(Long)session.getAttribute("userId");
				if(userId!=null){
					ArrayList productsList=dropShippingHelper.getMyProducts(userId);
					if(productsList!=null && productsList.size()!=0){
						for(int i=0;i<productsList.size();i++){
							Product product=(Product)productsList.get(i);
							XSSFRow row5=sheet.createRow((short)(i+5));
							XSSFCell cell=row5.createCell(0);
							cell.setCellValue(product.getSupplierPartNumber());
							cell=row5.createCell(1);
							cell.setCellValue(product.getManufacturerPartNumber());
							cell=row5.createCell(2);
							cell.setCellValue(product.getManufacturerName());
							cell=row5.createCell(3);
							cell.setCellValue(product.getDescription());
							cell=row5.createCell(4);
							cell.setCellValue(product.getImageUrl());
							cell=row5.createCell(5);
							cell.setCellValue(product.getUom());
							cell=row5.createCell(6);
							cell.setCellValue(product.getPrice());
							cell=row5.createCell(7);
							cell.setCellValue(product.getPkgQty());
							cell=row5.createCell(8);
							cell.setCellValue(product.getUpc());
							cell=row5.createCell(9);
							cell.setCellValue(product.getCategoryname());
						}
					}
				}
				
				ServletOutputStream out = response.getOutputStream();
				response.setContentType("application/vnd.ms-excel");
				String filename = "MyProducts_Account_"+session.getAttribute("userAccountNumber")+".xlsx";
				response.setHeader("Content-disposition", "attachment; filename="+filename);
				response.setContentType(contentType);
				wb.write(out);					
				out.flush();
				out.close();					
				response.flushBuffer();
				return null;
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
			
		if("manageBuyProducts".equalsIgnoreCase(theForm.getAction())){
			try{
				ArrayList productsList=dropShippingHelper.getAllProducts();
				if(productsList!=null && productsList.size()!=0){
					request.setAttribute("productList",productsList);
				}
				return mapping.findForward("manageBuyProducts");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}		
		return mapping.findForward("success");
	}
}
